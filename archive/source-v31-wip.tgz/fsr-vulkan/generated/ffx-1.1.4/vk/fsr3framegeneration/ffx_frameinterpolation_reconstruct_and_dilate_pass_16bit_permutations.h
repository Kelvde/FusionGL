#include "ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_6217d3a4a0e6344974e5f9c261001f1c.h"
#include "ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_95f78022983491daa76b32218141db00.h"
#include "ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_6e05464c6e2bc02f05ec1e9c8cffbd39.h"
#include "ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_96a45f81f37c8d73fe492e9c2723fa50.h"

typedef union ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_PermutationKey {
    struct {
        uint32_t FFX_FRAMEINTERPOLATION_OPTION_LOW_RES_MOTION_VECTORS : 1;
        uint32_t FFX_FRAMEINTERPOLATION_OPTION_JITTER_MOTION_VECTORS : 1;
        uint32_t FFX_FRAMEINTERPOLATION_OPTION_INVERTED_DEPTH : 1;
    };
    uint32_t index;
} ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_PermutationKey;

typedef struct ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_PermutationInfo {
    const uint32_t       blobSize;
    const unsigned char* blobData;


    const uint32_t  numConstantBuffers;
    const char**    constantBufferNames;
    const uint32_t* constantBufferBindings;
    const uint32_t* constantBufferCounts;
    const uint32_t* constantBufferSpaces;

    const uint32_t  numSRVTextures;
    const char**    srvTextureNames;
    const uint32_t* srvTextureBindings;
    const uint32_t* srvTextureCounts;
    const uint32_t* srvTextureSpaces;

    const uint32_t  numUAVTextures;
    const char**    uavTextureNames;
    const uint32_t* uavTextureBindings;
    const uint32_t* uavTextureCounts;
    const uint32_t* uavTextureSpaces;

    const uint32_t  numSRVBuffers;
    const char**    srvBufferNames;
    const uint32_t* srvBufferBindings;
    const uint32_t* srvBufferCounts;
    const uint32_t* srvBufferSpaces;

    const uint32_t  numUAVBuffers;
    const char**    uavBufferNames;
    const uint32_t* uavBufferBindings;
    const uint32_t* uavBufferCounts;
    const uint32_t* uavBufferSpaces;

    const uint32_t  numSamplers;
    const char**    samplerNames;
    const uint32_t* samplerBindings;
    const uint32_t* samplerCounts;
    const uint32_t* samplerSpaces;

    const uint32_t  numRTAccelerationStructures;
    const char**    rtAccelerationStructureNames;
    const uint32_t* rtAccelerationStructureBindings;
    const uint32_t* rtAccelerationStructureCounts;
    const uint32_t* rtAccelerationStructureSpaces;
} ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_PermutationInfo;

static const uint32_t g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_IndirectionTable[] = {
    3,
    1,
    3,
    1,
    2,
    0,
    2,
    0,
};

static const ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_PermutationInfo g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_PermutationInfo[] = {
    { g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_6217d3a4a0e6344974e5f9c261001f1c_size, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_6217d3a4a0e6344974e5f9c261001f1c_data, 1, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_6217d3a4a0e6344974e5f9c261001f1c_CBVResourceNames, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_6217d3a4a0e6344974e5f9c261001f1c_CBVResourceBindings, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_6217d3a4a0e6344974e5f9c261001f1c_CBVResourceCounts, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_6217d3a4a0e6344974e5f9c261001f1c_CBVResourceSets, 2, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_6217d3a4a0e6344974e5f9c261001f1c_TextureSRVResourceNames, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_6217d3a4a0e6344974e5f9c261001f1c_TextureSRVResourceBindings, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_6217d3a4a0e6344974e5f9c261001f1c_TextureSRVResourceCounts, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_6217d3a4a0e6344974e5f9c261001f1c_TextureSRVResourceSets, 3, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_6217d3a4a0e6344974e5f9c261001f1c_TextureUAVResourceNames, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_6217d3a4a0e6344974e5f9c261001f1c_TextureUAVResourceBindings, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_6217d3a4a0e6344974e5f9c261001f1c_TextureUAVResourceCounts, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_6217d3a4a0e6344974e5f9c261001f1c_TextureUAVResourceSets, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, },
    { g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_95f78022983491daa76b32218141db00_size, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_95f78022983491daa76b32218141db00_data, 1, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_95f78022983491daa76b32218141db00_CBVResourceNames, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_95f78022983491daa76b32218141db00_CBVResourceBindings, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_95f78022983491daa76b32218141db00_CBVResourceCounts, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_95f78022983491daa76b32218141db00_CBVResourceSets, 2, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_95f78022983491daa76b32218141db00_TextureSRVResourceNames, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_95f78022983491daa76b32218141db00_TextureSRVResourceBindings, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_95f78022983491daa76b32218141db00_TextureSRVResourceCounts, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_95f78022983491daa76b32218141db00_TextureSRVResourceSets, 3, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_95f78022983491daa76b32218141db00_TextureUAVResourceNames, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_95f78022983491daa76b32218141db00_TextureUAVResourceBindings, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_95f78022983491daa76b32218141db00_TextureUAVResourceCounts, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_95f78022983491daa76b32218141db00_TextureUAVResourceSets, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, },
    { g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_6e05464c6e2bc02f05ec1e9c8cffbd39_size, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_6e05464c6e2bc02f05ec1e9c8cffbd39_data, 1, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_6e05464c6e2bc02f05ec1e9c8cffbd39_CBVResourceNames, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_6e05464c6e2bc02f05ec1e9c8cffbd39_CBVResourceBindings, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_6e05464c6e2bc02f05ec1e9c8cffbd39_CBVResourceCounts, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_6e05464c6e2bc02f05ec1e9c8cffbd39_CBVResourceSets, 2, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_6e05464c6e2bc02f05ec1e9c8cffbd39_TextureSRVResourceNames, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_6e05464c6e2bc02f05ec1e9c8cffbd39_TextureSRVResourceBindings, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_6e05464c6e2bc02f05ec1e9c8cffbd39_TextureSRVResourceCounts, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_6e05464c6e2bc02f05ec1e9c8cffbd39_TextureSRVResourceSets, 3, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_6e05464c6e2bc02f05ec1e9c8cffbd39_TextureUAVResourceNames, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_6e05464c6e2bc02f05ec1e9c8cffbd39_TextureUAVResourceBindings, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_6e05464c6e2bc02f05ec1e9c8cffbd39_TextureUAVResourceCounts, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_6e05464c6e2bc02f05ec1e9c8cffbd39_TextureUAVResourceSets, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, },
    { g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_96a45f81f37c8d73fe492e9c2723fa50_size, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_96a45f81f37c8d73fe492e9c2723fa50_data, 1, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_96a45f81f37c8d73fe492e9c2723fa50_CBVResourceNames, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_96a45f81f37c8d73fe492e9c2723fa50_CBVResourceBindings, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_96a45f81f37c8d73fe492e9c2723fa50_CBVResourceCounts, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_96a45f81f37c8d73fe492e9c2723fa50_CBVResourceSets, 2, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_96a45f81f37c8d73fe492e9c2723fa50_TextureSRVResourceNames, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_96a45f81f37c8d73fe492e9c2723fa50_TextureSRVResourceBindings, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_96a45f81f37c8d73fe492e9c2723fa50_TextureSRVResourceCounts, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_96a45f81f37c8d73fe492e9c2723fa50_TextureSRVResourceSets, 3, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_96a45f81f37c8d73fe492e9c2723fa50_TextureUAVResourceNames, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_96a45f81f37c8d73fe492e9c2723fa50_TextureUAVResourceBindings, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_96a45f81f37c8d73fe492e9c2723fa50_TextureUAVResourceCounts, g_ffx_frameinterpolation_reconstruct_and_dilate_pass_16bit_96a45f81f37c8d73fe492e9c2723fa50_TextureUAVResourceSets, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, },
};

